PREPARED MATLAB CROSS-CHECK, NOT EXECUTION EVIDENCE

Extract the ZIP in MATLAB or MATLAB Online, open its folder, then run:
    run_stage2
The console prints convergence for 21 core cases and 8 Stage 1 readout checks.
Preserve matlab_output.json and matlab_run.log. Completed cases are saved as
the run proceeds; rerun run_stage2 to resume the same request after interruption.
Copy/download that file into the project's results/stage2 folder, then run:
    .\.venv\Scripts\python.exe experiments/stage2/publish_matlab.py
Only a verified actual MATLAB report completes the runtime check.
QSPPACK is included unchanged from the pinned Git commit, with its LICENSE.
The MATLAB runner verifies six source hashes again before computation.
No account credentials or private GitHub access are included or needed.
