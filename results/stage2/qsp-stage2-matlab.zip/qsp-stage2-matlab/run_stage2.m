function run_stage2
% Run after extracting this bundle in MATLAB or MATLAB Online.
% All numerical inputs and original QSPPACK source are included locally.
bundle_root = fileparts(mfilename('fullpath'));
addpath(bundle_root);
diary(fullfile(bundle_root, 'matlab_run.log'));
cleanup = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Actual MATLAB runtime: %s\n', version);
crosscheck_matlab(fullfile(bundle_root, 'QSPPACK'), ...
    fullfile(bundle_root, 'matlab_input.json'), ...
    fullfile(bundle_root, 'matlab_output.json'));
end
