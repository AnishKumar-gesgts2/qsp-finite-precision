% Run after extracting this bundle in MATLAB or MATLAB Online.
% All numerical inputs and original QSPPACK source are included locally.
bundle_root = fileparts(mfilename('fullpath'));
addpath(bundle_root);
crosscheck_matlab(fullfile(bundle_root, 'QSPPACK'), ...
    fullfile(bundle_root, 'matlab_input.json'), ...
    fullfile(bundle_root, 'matlab_output.json'));
